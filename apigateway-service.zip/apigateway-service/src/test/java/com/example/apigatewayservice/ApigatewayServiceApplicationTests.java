package com.example.apigatewayservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApigatewayServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
