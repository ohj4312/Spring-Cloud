package com.example.eccomerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EccomerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
